//
//  StaticFramework.h
//  StaticFramework
//
//  Created by Thanh Tran Van on 22/03/2021.
//

#import <Foundation/Foundation.h>

//! Project version number for StaticFramework.
FOUNDATION_EXPORT double StaticFrameworkVersionNumber;

//! Project version string for StaticFramework.
FOUNDATION_EXPORT const unsigned char StaticFrameworkVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <StaticFramework/PublicHeader.h>


