//
//  TestStaticFramework.swift
//  StaticFramework
//
//  Created by Thanh Tran Van on 22/03/2021.
//

import Foundation
import Alamofire

@objcMembers public class TestStaticFramework: NSObject {
    public static func testRequestAPI() {
        let parameters = [
          "username": "foo",
          "password": "123456"
        ]

        AF.request("https://swapi.dev/api/films/", method: .get, parameters: parameters).validate().responseJSON { result in
            print("Result \(result)")
        }
    }
}
