//
//  TestDynamicFramework.swift
//  TestFramework
//
//  Created by Thanh Tran Van on 22/03/2021.
//

import Foundation
@_implementationOnly import StaticFramework

@objcMembers public class TestDynamicFramework: NSObject {
    public static func testRequestAPI() {
        TestStaticFramework.testRequestAPI()
    }
}
